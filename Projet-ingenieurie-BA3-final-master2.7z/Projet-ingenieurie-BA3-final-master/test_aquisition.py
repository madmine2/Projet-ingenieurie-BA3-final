import cv2
# import the opencv library
import numpy as np

from PIL import Image, ImageDraw

face_colour = []

refLow = [[165, 80, 150], [45, 52, 72], [90, 80, 2], [24, 150, 100]]
refHigh = [[184, 255, 255], [60, 255, 255], [110, 255, 255], [35, 255, 180]]
ref2Low = [[0, 0, 60], [30, 120, 0], [90, 80, 2], [0, 80, 60]]
ref2High = [[60, 20, 150], [85, 255, 255], [110, 255, 255], [20, 100, 150]]
ref = [[178 ,196 ,134],[ 51 ,228 , 86],[ 95 ,219  ,77],[ 26, 255 ,135]]
refLow3 = []
refHigh3 = []
for i in range(4):
    refLow3.append([a - 30 for a in ref[i]])
    refHigh3.append([a + 30 for a in ref[i]])
refLow = refLow3
refHigh = refHigh3


def findColor(frame, x, y, I):
    # take part of the image
    temp_x = x
    x = y
    y = temp_x
    temp_frame = frame[x - 10:x + 10, y - 10:y + 10]
    color = ["rouge", "vert", "bleu", "jaune"]
    color_id = ["1", "2", "3", "4"]

    color_dict = {"rouge": 0, "bleu": 0, "jaune": 0, "vert": 0}

    # make dict of the colors in the image
    for i in range(20):
        for j in range(20):
            colorPixel = False
            best_color = 99999999
            for k in range(4):
                color_temp = 0
                for l in range(3):
                    color_temp += abs(ref[k][l] - temp_frame[i][j][l])
                if color_temp < best_color:
                    best_color = color_temp
                    colorPixel = k

            color_dict[color[colorPixel]] += 1

    # Sort them by count number(first element of tuple)
    temppp = 0
    color_dom = "0"
    for i in range(4):
        if color_dict[color[i]] >= temppp:
            temppp = color_dict[color[i]]
            color_dom = color_id[i]
    print(color_dom)
    return color_dom


def capture_video():
    # define a video capture object
    vid = cv2.VideoCapture(1)

    pos = 0
    temp = 0

    while True:
        # Capture the video frame
        # by frame
        ret, frame = vid.read()

        frame = Image.fromarray(frame)

        draw = ImageDraw.Draw(frame, "RGBA")

        coordTriangleX = [300, 200, 300, 400, 100, 200, 300, 400, 500]
        coordTriangleY = [100, 250, 200, 250, 400, 350, 400, 350, 400]
        for i in range(9):
            x = coordTriangleX[i]
            y = coordTriangleY[i]

            draw.rectangle((x - 10, y - 10, x + 10, y + 10), outline=(0, 0, 0, 125))
        draw.rectangle((300 - 2, 200 - 2, 300 + 2, 200 + 2), outline=(100, 100, 100, 125))
        frame = np.array(frame)

        hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        if cv2.waitKey(1) & 0xFF == ord('p'):
            print(hsv_frame[200, 300])

        if cv2.waitKey(1) & 0xFF == ord(' '):
            face_temp = ""
            for i in range(9):
                x = coordTriangleX[i]
                y = coordTriangleY[i]
                face_temp += findColor(hsv_frame, x, y, i)
                print(face_temp)

            face_colour.append(int(face_temp))
            print(face_colour)
            # return face_colour

        # Red color
        low_red = np.array(refLow[0])
        high_red = np.array(refHigh[0])
        red_mask = cv2.inRange(hsv_frame, low_red, high_red)
        red = cv2.bitwise_and(frame, frame, mask=red_mask)

        # Blue color
        low_blue = np.array(refLow[2])
        high_blue = np.array(refHigh[2])
        blue_mask = cv2.inRange(hsv_frame, low_blue, high_blue)
        blue = cv2.bitwise_and(frame, frame, mask=blue_mask)
        # Green color
        low_green = np.array(refLow[1])
        high_green = np.array(refHigh[1])
        green_mask = cv2.inRange(hsv_frame, low_green, high_green)
        green = cv2.bitwise_and(frame, frame, mask=green_mask)
        # Yellow color
        low_yellow = np.array(refLow[3])
        high_yellow = np.array(refHigh[3])
        yellow_mask = cv2.inRange(hsv_frame, low_yellow, high_yellow)
        yellow = cv2.bitwise_and(frame, frame, mask=yellow_mask)
        cv2.imshow("Frame", frame)
        # cv2.imshow("Hsv_Frame", hsv_frame)

        cv2.imshow("Red", red)
        cv2.imshow("Blue", blue)
        cv2.imshow("Green", green)
        cv2.imshow("Yellow", yellow)


        # the 'q' button is set as the
        # quitting button you may use any
        # desired button of your choice
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        if cv2.waitKey(1) & 0xFF == ord('s'):
            pos += 1
            if pos > 5:
                pos = 0

    # After the loop release the cap object
    vid.release()
    # Destroy all the windows
    cv2.destroyAllWindows()


# Press the green button in the gutter to run the script.

def main():
    matrix = []
    for i in range(4):
        matrix.append()


if __name__ == '__main__':
    capture_video()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
